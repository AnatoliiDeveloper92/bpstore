import flet as ft

from pages.home import home_page
from pages.details import details_page
from pages.confirm_order import cart_page
from pages.storage import state_manager

def main(page: ft.Page):
    page.title = "Магазин"
    page.horizontal_alignment = "center"
    page.vertical_alignment = "center"
    # page.window.width = 360
    # page.window.height = 500
    # page.window.min_width = 320
    # page.window.min_height = 400

    def set_page(e):
        ind = e.control.selected_index
        if ind == 0:
            page.go("/home")
        elif ind == 1:
            page.go("/cart")

    menu = ft.NavigationBar(
        destinations=[
            ft.NavigationBarDestination(icon=ft.Icons.HOME_OUTLINED, label="Home"),
            ft.NavigationBarDestination(icon=ft.Icons.SHOPPING_CART_OUTLINED, label="Cart"),
        ],
        on_change=lambda e: set_page(e)
    )

    def route_change(route):
        page.views.clear()

        if page.route == '/home':
            page.views.append(
                ft.View(
                    '/home',
                    [home_page(page),
                    menu
                    ],
                    vertical_alignment=ft.MainAxisAlignment.START,
                    horizontal_alignment=ft.CrossAxisAlignment.CENTER,
                )
            )
        elif page.route == '/details':
            page.views.append(
                ft.View(
                    '/details',
                    [details_page(page, state_manager.curent_product),
                    menu
                    ],
                    vertical_alignment=ft.MainAxisAlignment.START,
                    horizontal_alignment=ft.CrossAxisAlignment.CENTER,
                )
            )
        elif page.route == '/cart':
            if not hasattr(state_manager, 'cart'):
                state_manager.cart = []

            page.views.append(
                ft.View(
                    '/cart',
                    [cart_page(page, state_manager.cart), menu],
                    vertical_alignment=ft.MainAxisAlignment.START,
                    horizontal_alignment=ft.CrossAxisAlignment.CENTER,
                )
            )
        page.update()

    page.on_route_change = route_change
    page.go('/home')
    
if __name__ == '__main__':
    ft.app(target=main, view=ft.WEB_BROWSER)
