import flet as ft
from pages.storage import state_manager

import requests

def send_order(order):
    TOKEN = '8074565110:AAHfY_8dWI2ZB7aBGYYXOEuZ7ZGiWk4FGHQ'
    chat_id = "929204762"
    message = f"""
    Новый заказ!\n
    Наименование товара: {order['product']}\n
    Данные игрового аккаунта: {order['login']}\n
    Номер для связи: {order['phone_number']}\n
    Комментарий к заказу: {order['comment']}"""
    url = f"https://api.telegram.org/bot{TOKEN}/sendMessage?chat_id={chat_id}&text={message}"
    requests.get(url).json()

# {
#     product: state_manager.cart['name'],
#     login: ''
#     phone_number: ''
#     comment: ''
# }

def cart_page(page: ft.Page, cart):
    if cart:
        good_line = ft.Row(
            [
                ft.Text(cart['name']),
                ft.Text(f"{cart['price']} $"),
            ], )
    else:
        good_line = ft.Text('Cart is empty', size=32)

    login_field = ft.TextField(label="Login in game or game id", width=300)
    phone_field = ft.TextField(label="Phone number +79998887766", width=300)
    comment_field = ft.TextField(label="Comments", width=300, height=300)

    def get_values(e):
        o = {
                'product': state_manager.cart['name'],
                'login': login_field.value,
                'phone_number': phone_field.value,
                'comment': comment_field.value
            }
        send_order(o)
        # ! включить проверку полей (все ли заполнены)
        # ! если нет показать alert с уведомлением о необходимости заполнить все
        # ! если все ок, покать alert (Заявка оформлена, скоро мы с вами свяжемся)

    # Обернуть Column в ListView для прокрутки
    return ft.ListView(
        [
            ft.Column(
                [
                    good_line,
                    ft.Divider(),
                    login_field,
                    phone_field,
                    comment_field,
                    ft.ElevatedButton('Confirm', width=300, on_click=get_values)
                ],
                alignment=ft.MainAxisAlignment.CENTER,
                horizontal_alignment=ft.CrossAxisAlignment.CENTER,
                spacing=10
            )
        ],
        expand=True  # Растягивается на всю доступную высоту
    )
