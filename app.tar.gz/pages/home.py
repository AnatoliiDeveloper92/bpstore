import flet as ft
from pages.storage import state_manager

def home_page(page: ft.Page):

    products = [
        {"name": "Call of Duty: Warzone", "price": 10.99, "image": "https://i.playground.ru/e/BuWudNDwoD9mmqp_2fKQyw.jpeg"},
        {"name": "PUBG", "price": 10.99, "image": "https://avatars.mds.yandex.net/i?id=99cfbb7d8677455fe6bca256b2bcc6ae_l-5449748-images-thumbs&n=13"},
        {"name": "Fortnite", "price": 10.99, "image": "https://pic.rutubelist.ru/video/2024-09-20/01/76/0176f7eac515637f4f0a5b63ca8056fc.jpg"},
        {"name": "Delta Force", "price": 10.99, "image": "https://steamuserimages-a.akamaihd.net/ugc/2492264950613846516/E2F4BC26C7E0B0B8077533DC622CD3128DB64CE6/?imw=512&amp;imh=288&amp;ima=fit&amp;impolicy=Letterbox&amp;imcolor=%23000000&amp;letterbox=true"},
    ]

    def see_more(e, product):
        state_manager.curent_product = product
        page.go('/details')

    product_cards = []
    for p in products:
        card = ft.Card(
            content=ft.Column(
                [
                    ft.Image(src=p['image'], width=360, height=150),
                    ft.Text(p['name'], size=18, weight='bold'),
                    ft.Row(
                        [
                            ft.ElevatedButton('Details', bgcolor='red', on_click=lambda e, product=p: see_more(e,product)),
                            ft.Text(f"Price: {p['price']} $", size=16),
                        ],
                        alignment=ft.MainAxisAlignment.CENTER
                    )
                ],
                alignment=ft.MainAxisAlignment.START,
                horizontal_alignment=ft.CrossAxisAlignment.CENTER,
                spacing=10
            ),
            width=360,
            height=200
        )
        product_cards.append(card)

    # Используем GridView для отображения карточек
    return ft.GridView(
        controls=product_cards,
        expand=1,
        runs_count=5,
        max_extent=360,
        child_aspect_ratio=1.0,
        spacing=5,
        run_spacing=5,
    )
