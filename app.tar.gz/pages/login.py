import flet as ft

def auth_page(page: ft.Page):
    error_text = ft.Text('', color='red')
     # Form controls
    login = ft.TextField(label="Username", width=300)
    password = ft.TextField(label="Password", password=True, width=300)

    def login_click(e):
        # TODO тут будет логика авторизации
        page.go('/home')
    def go_to_registration(e):
        # TODO тут будет логика авторизации
        page.go('/registration')

    return ft.Column(
        [
            ft.Text('Authorization', size=24),
            login,
            password,
            ft.ElevatedButton('Login', on_click=login_click, width=300),
            ft.TextButton("Don't have an accont? Register", on_click=go_to_registration),
            error_text
        ],
        alignment=ft.MainAxisAlignment.CENTER,
        horizontal_alignment=ft.CrossAxisAlignment.CENTER,
        spacing=20
    )
